<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh">
<context>
    <name>AddTaskWindowClass</name>
    <message>
        <location filename="addtaskwindow.ui" line="14"/>
        <source>AddTaskWindow</source>
        <translation>AddTaskWindow</translation>
    </message>
    <message>
        <location filename="addtaskwindow.ui" line="47"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="addtaskwindow.ui" line="60"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="addtaskwindow.ui" line="73"/>
        <source>×</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="addtaskwindow.ui" line="101"/>
        <source>Each URL on a separate line</source>
        <translation>每个URL之间使用换行分隔</translation>
    </message>
</context>
<context>
    <name>DownloadCardClass</name>
    <message>
        <location filename="downloadcard.ui" line="26"/>
        <source>DownloadCard</source>
        <translation>DownloadCard</translation>
    </message>
    <message>
        <location filename="downloadcard.ui" line="59"/>
        <source>×</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="downloadcard.ui" line="101"/>
        <source>||</source>
        <translation>||</translation>
    </message>
    <message>
        <location filename="downloadcard.ui" line="114"/>
        <source>FILENAME</source>
        <translation>FILENAME</translation>
    </message>
    <message>
        <location filename="downloadcard.ui" line="135"/>
        <source>☑</source>
        <translation>☑</translation>
    </message>
</context>
<context>
    <name>DownloadDetailCardClass</name>
    <message>
        <location filename="downloaddetailcard.ui" line="14"/>
        <source>DownloadDetailCard</source>
        <translation>DownloadDetailCard</translation>
    </message>
    <message>
        <location filename="downloaddetailcard.ui" line="47"/>
        <source>%p%</source>
        <translation>%p%</translation>
    </message>
    <message>
        <location filename="downloaddetailcard.ui" line="60"/>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
</context>
<context>
    <name>DownloadDetailClass</name>
    <message>
        <location filename="downloaddetail.ui" line="16"/>
        <source>DownloadDetail</source>
        <translation>DownloadDetail</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>文件下载助手</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="49"/>
        <source>Download Helper</source>
        <translation>文件下载助手</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="123"/>
        <source>×</source>
        <translation>×</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="136"/>
        <source>+</source>
        <translation>+</translation>
    </message>
</context>
</TS>
